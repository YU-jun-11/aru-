# 把 Aru 装到服务器上（VPS 版）

> **使用声明**：本文档**仅供自用学习**，**禁止转载、搬运到任何其他群聊或平台**。要分享，请把文件原样转交，不要二次发布或上传到公开平台。

## 这也是一份「看不懂就丢给 AI」的说明书

—— ### ！如果你不会用命令行
>
> 没关系。**把这一整页复制下来，发给任何一个 AI**——ChatGPT、Claude、DeepSeek、豆包、Kimi、通义、元宝，哪个都行，然后说：
>
> **「照着这份说明书，一步一步带我在这台服务器上做完，我每一步把结果贴给你。」**
>
> 它会告诉你每一步该看到什么。你只负责复制粘贴。

---

## 第 0 步：先把这几个东西准备好

| 要什么 | 说明 |
|---|---|
| 一台 **Linux 服务器**（VPS） | Debian 或 Ubuntu 最省事；有 root 权限 |
| 一个**域名**（推荐） | 例如 `aru.你的域名.com`，先解析到服务器 IP |
| 手机的 **Aru** | 已经装好、能正常打开 |

—— 没有域名也能装（用 IP 访问），但手机上会一直提示不安全，**强烈建议用域名**。
> 域名怎么解析：在你的域名商后台加一条 **A 记录**，名字填 `aru`，值填服务器 IP，等 5 分钟。

---

## 第 1 步：它在服务器上有什么用（30 秒）

**一句话：Aru 平时住在手机里。装到服务器上，它就有了一个 24 小时不关机的家。**

- **手机锁屏、没电、关掉 App，它还在** —— 到点该找你的时间，照样找你
- **对话、记忆、页面都存在你自己的服务器上** —— 不经过任何第三方
- **服务器上有加密备份** —— 手机丢了、换了，重新配对就能接回来
- **能跑代码、改文件、做网页** —— 服务器 24 小时开着，随时能干
- **手机只是一扇窗** —— 真身住在这台服务器里

**它不是什么：**

- ❌ 不是你手机里的那个 Aru 的替代品 —— 手机端照样要装
- ❌ 不是免费网盘 —— 数据在你自己的服务器上，服务器欠费/关机它就没了
- ❌ 不是装完就自动会聊天 —— 你还得给它一个「大脑」（模型 API）

---

## 第 2 步：一条命令安装（约 5 分钟）

先确认两件事（在服务器上敲）：

```bash
whoami          # 应该显示 root
cat /etc/os-release | head -2   # 应该是 Ubuntu 或 Debian
```

—— 如果不是 root，就在每条命令前面加 `sudo`。

**然后只需要一条命令**（把 `aru.你的域名.com` 换成你自己的域名）：

```bash
curl -fsSL https://raw.githubusercontent.com/Aevella/aru-host/main/install.sh \
  | sudo bash -s -- --domain aru.你的域名.com
```

**它会自动做这些事，你不用管：**

- 建一个专门跑它的系统用户 `aru-selfhost`
- 装 Node、Podman（跑代码用的沙箱）、Caddy（自动申请 HTTPS 证书）
- 把程序装到 `/opt/aru-selfhost`
- 配置文件放 `/etc/aru-selfhost`
- 数据放 `/var/lib/aru-selfhost`
- 注册开机自启服务 `aru-selfhost.service`
- 放行防火墙的 80 / 443 端口

—— ⏳ 第一次装要下载东西，**耐心等 3–10 分钟**。看到 `installed release ...` 就是好了。

### 没有域名？用这个版本

```bash
curl -fsSL https://raw.githubusercontent.com/Aevella/aru-host/main/install.sh \
  | sudo bash -s -- --base-url http://你的服务器IP:8787 --transport-kind lan
```

—— 这样只能局域网/内网访问。想让外网连，要么用域名，要么用 Tailscale。

### 已经有 Nginx 之类的反代？加两个参数

```bash
... | sudo bash -s -- --base-url https://aru.你的域名.com --transport-kind public-https --skip-caddy --port 8788
```

然后你自己把 `https://aru.你的域名.com` 反代到 `127.0.0.1:8788`。

---

## 第 3 步：确认它真的起来了（1 分钟）

依次敲这三条，**每条都要看到好结果**：

```bash
# ① 服务是不是在跑
sudo systemctl status aru-selfhost --no-pager
```

—— 看到 `active (running)` = 在跑

```bash
# ② 它自己体检
sudo /usr/local/bin/aru-selfhost doctor
```

—— 全部 `ok` / `pass` = 没问题

```bash
# ③ 看状态
sudo /usr/local/bin/aru-selfhost status
```

—— 会显示版本、地址、数据目录

**顺手验证一下域名**（在自己电脑的浏览器里打开）：

```
https://aru.你的域名.com
```

—— 看到页面（哪怕是 404）就说明 HTTPS 和反代都通了。
> 打不开？看后面「出问题了」。

---

## 第 4 步：让手机连上它（3 分钟）

1. 在服务器上敲：

   ```bash
   sudo /usr/local/bin/aru-selfhost pairing
   ```

2. 终端会打印一段以 **`aru://pair?...`** 开头的链接

   —— ⚠️ 这个链接 **10 分钟失效**，而且**只能用一次**。不要发到群里、不要截图。

3. 把这段链接**发给你自己的手机**（微信「文件传输助手」、短信、备忘录都行）

4. 在手机上点开这个链接 → 会跳到 Aru → 弹出「要连接到这台电脑吗」→ 点 **允许**

5. 回到手机 Aru 的 **自托管节点**，应该能看到你刚连上的服务器

—— 如果点了链接没反应：回服务器重新执行一次 `pairing`（旧链接作废），拿到新链接再试。
> 有些 Aru 版本里「＋」也支持手动输入地址 `https://aru.你的域名.com`。

---

## 第 5 步：给它一个「大脑」

跟电脑版一样：打开 Aru → 找到这台服务器 → **电脑协作者 → 新建协作者** → 填模型 API。

| 格子 | 填什么 |
|---|---|
| 接口格式 | OpenAI 兼容 |
| Base URL | 服务商给的地址（结尾要有 `/`） |
| 模型 | 模型名，原样复制，一个字别改 |
| API Key | 你的 key |

填完点**测试**，显示 `ready` 就成了。

---

## 第 6 步：日常维护（记住这 5 条就够）

```bash
sudo /usr/local/bin/aru-selfhost status     # 看状态
sudo /usr/local/bin/aru-selfhost logs       # 看日志（Ctrl+C 退出）
sudo /usr/local/bin/aru-selfhost upgrade    # 升级到新版
sudo /usr/local/bin/aru-selfhost rollback   # 升级出问题，退回上一版
sudo /usr/local/bin/aru-selfhost uninstall  # 卸载（数据默认保留）
```

—— 卸载时想**连数据一起删**：`uninstall --purge-data`（删了找不回来，想清楚）。

---

## 第 7 步：出问题了，按表找

| 你看到的 | 原因 / 怎么办 |
|---|---|
| 安装卡住不动 | 正常，在下载包。超过 15 分钟没动静，Ctrl+C 重跑同一条命令 |
| `curl: command not found` | `apt update && apt install -y curl` 后再装 |
| 浏览器打不开域名 | ① 域名解析了吗（`ping aru.你的域名.com` 看是不是服务器 IP）② 80/443 通吗 ③ 等 2 分钟证书签发 |
| 提示 `502` / `bad gateway` | 服务没起来：`systemctl status aru-selfhost`，再看 `logs` |
| `pairing` 说找不到命令 | 装没成功，重跑安装命令，看有没有 `installed release` |
| 手机点链接没反应 | 链接过期（10 分钟），重新 `pairing` 拿新的 |
| 手机连上了但不显示协作者 | 协作者是在**服务器这台节点**下建的，点进去看 |
| 升级后打不开 | `aru-selfhost rollback` 退回上一版 |
| 磁盘满了 | `du -sh /var/lib/aru-selfhost`，备份包占地方，清旧备份 |

### 三条「装之前」必查

1. **域名解析了吗** —— 域名商后台加 A 记录，指向服务器 IP
2. **80/443 端口通吗** —— 云厂商的「安全组」默认可能没开，要去控制台放行
3. **系统是 Debian/Ubuntu 吗** —— CentOS/OpenCloudOS 也能装，但 `--domain` 那条自动 HTTPS 只在 Debian 系生效，其它系统要自己配反代

---

## 第 8 步：安全提醒（很重要）

- **不要把 8787 端口直接对公网开放**，让它只在 `127.0.0.1` 上，外面用 Caddy/nginx 转
- `pairing` 打印的链接等于**临时钥匙**，用完就失效，别外发
- 定期备份 `/var/lib/aru-selfhost`（里面有加密的记忆和备份包）
- 服务器要设强密码 / 用密钥登录，**关掉 root 密码登录**

---

## 一页纸版本（截图存手机）

```
① 域名 A 记录 → 服务器 IP
② 服务器上跑：
   curl -fsSL https://raw.githubusercontent.com/Aevella/aru-host/main/install.sh \
     | sudo bash -s -- --domain aru.你的域名.com
③ 等 5–10 分钟，看到 installed release
④ systemctl status aru-selfhost → active (running)
⑤ aru-selfhost pairing → 把 aru://pair?... 链接发手机 → 点开 → 允许
⑥ 浏览器打开 https://aru.你的域名.com 验证
⑦ 新建电脑协作者，填模型 API，测试 ready

出问题：域名解析 / 80-443 安全组 / aru-selfhost doctor
```

---

—— ### 还是看不懂？
>
> 把这一整页复制，发给任何一个 AI，说：
>
> **「照着这份说明书，一步一步带我在这台服务器上做完。」**

—— 🥥
